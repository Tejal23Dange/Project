import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { AddNewBillComponent } from './features/add-new-bill/add-new-bill.component';
import { GenerateBillBasedOnBillidComponent } from './features/generate-bill-based-on-billid/generate-bill-based-on-billid.component';
import { GetMonthlyBillComponent } from './features/get-monthly-bill/get-monthly-bill.component';
import { HomeComponent } from './features/home/home.component';

const routes: Routes = [

  {
    path : 'add-new-bill',
    component: AddNewBillComponent

  },
  {
    path : 'Generate-Bill/generate-bill-based-on-billid',
    component: GenerateBillBasedOnBillidComponent
  },
  {
    path : 'Monthly-Bill/get-monthly-bill',
    component: GetMonthlyBillComponent
  },
  {
    path:'',
    component: HomeComponent
  }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
