 import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
// import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavBarComponent } from './core/component/nav-bar/nav-bar.component';
import { AddNewBillComponent } from './features/add-new-bill/add-new-bill.component';
import { GenerateBillBasedOnBillidComponent } from './features/generate-bill-based-on-billid/generate-bill-based-on-billid.component';
import { GetMonthlyBillComponent } from './features/get-monthly-bill/get-monthly-bill.component';
import { HomeComponent } from './features/home/home.component';
// import { HttpClientModule } from '@angular/common/http';  


@NgModule({
  declarations: [
    AppComponent,
    NavBarComponent,
    AddNewBillComponent,
    GenerateBillBasedOnBillidComponent,
    GetMonthlyBillComponent,
    HomeComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
    
  ],
  providers: [],
  bootstrap: [AppComponent] //decides which component should start
})
export class AppModule { }
