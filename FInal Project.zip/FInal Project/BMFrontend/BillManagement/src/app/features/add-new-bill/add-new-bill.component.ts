import { Component, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { AddBill } from '../models/add-new-bill.model';
import { BillService } from '../services/bill.service';

@Component({
  selector: 'app-add-new-bill',
  templateUrl: './add-new-bill.component.html',
  styleUrl: './add-new-bill.component.css'
})
export class AddNewBillComponent{

model: AddBill;
private BillSubscription?: Subscription;
billId?: Number;

constructor(private service:BillService){
  this.model ={
    feeId : null,
    noOfKm: null,
    driverId: null,
    noOfOccupants : null,
    rideStatus : "Completed",
    rideId : null
  };
}

  onFormSubmit(){
    this.BillSubscription = this.service.postBill(this.model)
    .subscribe({
      next: (response) => {
        alert("Submitted Successfully");
        this.billId = response;
        console.log(response);
      }
    })

  }


  //ngOnDestroy(): void {
  //  this.BillSubscription?.unsubscribe();
  //}

}
