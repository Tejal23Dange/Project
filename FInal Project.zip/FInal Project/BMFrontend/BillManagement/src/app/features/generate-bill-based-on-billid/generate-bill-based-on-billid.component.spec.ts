import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateBillBasedOnBillidComponent } from './generate-bill-based-on-billid.component';

describe('GenerateBillBasedOnBillidComponent', () => {
  let component: GenerateBillBasedOnBillidComponent;
  let fixture: ComponentFixture<GenerateBillBasedOnBillidComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [GenerateBillBasedOnBillidComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(GenerateBillBasedOnBillidComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
