import { Component, OnDestroy } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Subscription } from 'rxjs';
import { GenerateBill } from '../models/generate-bill.model';
import { GeneratedBill } from '../models/generated-bill.model';
import { BillService } from '../services/bill.service';

@Component({
  selector: 'app-generate-bill-based-on-billid',
  templateUrl: './generate-bill-based-on-billid.component.html',
  styleUrl: './generate-bill-based-on-billid.component.css'
})
export class GenerateBillBasedOnBillidComponent{

  model: GenerateBill;
  private BillSubscription?: Subscription;
  opmodel: GeneratedBill;

  constructor(private service:BillService){
    this.model ={
      billId: null
    };
  }

  

  onFormSubmit(){
    this.BillSubscription = this.service.getBill(this.model)
    .subscribe({
      next: (response) => {
        alert("Submitted Successfully");
        console.log(response);
        this.opmodel = response;
      }
    });
  }

  //ngOnDestroy(): void {
  //  this.BillSubscription.unsubscribe();
  //}
}
