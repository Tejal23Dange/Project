import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetMonthlyBillComponent } from './get-monthly-bill.component';

describe('GetMonthlyBillComponent', () => {
  let component: GetMonthlyBillComponent;
  let fixture: ComponentFixture<GetMonthlyBillComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [GetMonthlyBillComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(GetMonthlyBillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
