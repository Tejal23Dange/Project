import { Component, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { DriverReport } from '../models/driver-report.model';
import { MonthlyBill } from '../models/get-monthly-bill.model';
import { BillService } from '../services/bill.service';

@Component({
  selector: 'app-get-monthly-bill',
  templateUrl: './get-monthly-bill.component.html',
  styleUrl: './get-monthly-bill.component.css'
})
export class GetMonthlyBillComponent{

  model: MonthlyBill;
  private BillSubscription?: Subscription;
  opmodel: DriverReport;

  constructor(private service:BillService){
    this.model ={
      driverId : null,
      month: ''
    };
  }

  onFormSubmit(){
    this.BillSubscription = this.service.getReport(this.model)
    .subscribe({
      next: (response) => {
       alert("Submitted Successfully");
        console.log(response);
        this.opmodel = response;
      }
    });
  }

  //ngOnDestroy(): void {
  //  this.BillSubscription.unsubscribe();
  //}

}
