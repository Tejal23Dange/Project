export interface AddBill{
    feeId : number;
    noOfKm : number;
    rideId : number;
    driverId : number;
    rideStatus: string;
    noOfOccupants : number;
//     totalBill : number;
}