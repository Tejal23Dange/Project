export interface DriverReport
{
    driverId: Number,
    totalBill: Number
}