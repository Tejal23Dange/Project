export interface GenerateBill{
    billId : number;

}