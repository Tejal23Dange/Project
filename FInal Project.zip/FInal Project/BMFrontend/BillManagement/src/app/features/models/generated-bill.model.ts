export interface GeneratedBill
{
    billId?: Number,
    driverId?: Number,
    rideId?: Number,
    noOfKm?: Number,
    totalBill?: Number,
    noOfOccupants?: Number,
    feeId?: Number,
    costPerOccupant?: Number
  }