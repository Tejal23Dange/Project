export interface MonthlyBill{
    driverId : number;
    month:string;
}