import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AddBill } from '../models/add-new-bill.model';
import { DriverReport } from '../models/driver-report.model';
import { GenerateBill } from '../models/generate-bill.model';
import { GeneratedBill } from '../models/generated-bill.model';
import { MonthlyBill } from '../models/get-monthly-bill.model';

@Injectable({
  providedIn: 'root'
})
export class BillService {

  constructor(private http:HttpClient) { }

  postBill(model: AddBill): Observable<any>{
    return this.http.post<any>('http://localhost:5029/api/BillManagement/bill/new', model)
  }

  getBill(model: GenerateBill): Observable<GeneratedBill>{
    return this.http.get<GeneratedBill>('http://localhost:5029/api/BillManagement/bill/'+model.billId)
  }

  getReport(model: MonthlyBill): Observable<DriverReport>{
  return this.http.get<DriverReport>('http://localhost:5029/api/BillManagement/bill/'+model.month+"/"+model.driverId)
  }
}
