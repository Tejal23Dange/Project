﻿using BillManagement_DAL.DBContext;
using BillManagement_DAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BillManagement_BAL.Repository
{
    public class BillManagementRepository : iBillManagementRepository1
    {
        private readonly BillManagementContext _context;

        public BillManagementRepository(BillManagementContext context)
        {
            _context = context;
        }

        public void GenerateNewBill(billMaster bill)
        {
            int feeid = bill.FeeId;
            var fee = _context.Fees.Where(c=>c.FeeId == feeid).FirstOrDefault();

            int costOfFuel = fee.CostOfFuel;
            int avgInKm = fee.AvgInKm;
            double fixedCostPerKm = costOfFuel / avgInKm;
            double costKmWise = fixedCostPerKm * bill.NoOfKm;
            double appCharges = 10; // App Charges assumed to be 10
            double totalCost = costKmWise + fee.WearTearCost + fee.DriverCharges + appCharges;
            double costPerPerson = totalCost / bill.NoOfOccupants;

            bill.TotalBill = (int)totalCost;
            bill.CostPerOccupant = (int)costPerPerson;

            _context.billMasters.Add(bill);
            _context.SaveChanges();
        }

        public billMaster? GetBill(int id)
        {
            return _context.billMasters.Where(c => c.BillId == id);
        }

     /*   public void GetMonthlyBill() 
        { 
          //Query to fetch monthly billing report based on month and driverId
            var monthlyReport = dbContext.
                .Where(b => b.DriverId == driverId && b.Date.Month == month)
                .Select(b => new MonthlyBill
                    {
                        Source = b.Source,
                        Destination = b.Destination
                        Bill = b.TotalBill,
                        DateTime = b.Date
                    })
                    .toList();
                
     
        }*/

    }
}
