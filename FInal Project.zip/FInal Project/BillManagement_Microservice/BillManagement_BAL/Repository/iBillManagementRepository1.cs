﻿using BillManagement_DAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace BillManagement_BAL.Repository
{
    public interface iBillManagementRepository1
    {
        public void GenerateNewBill(billMaster bill) { }

        public billMaster? GetBill(int id) { return null; }

        //public void GetMonthlyBill(int month, string driverId) { }
    }
}
