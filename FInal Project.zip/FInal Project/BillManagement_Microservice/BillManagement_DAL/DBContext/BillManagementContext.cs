﻿using BillManagement_DAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BillManagement_DAL.DBContext
{
    public class BillManagementContext : DbContext
    {

        public BillManagementContext() { }

        public BillManagementContext(DbContextOptions<BillManagementContext> options) : base(options)
        {
        }

        public DbSet<Fee> Fees { get; set; }

        public DbSet<billMaster> billMasters { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=LTIN240001;Initial Catalog=CandidateDB;TrustServerCertificate=True;Integrated Security=SSPI;");
            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //primary key for Fee entity
            modelBuilder.Entity<Fee>()
                .HasKey(f => f.FeeId);

            //foreign key relationship between Fee and billMaster
            modelBuilder.Entity<billMaster>()
                .HasOne(b => b.Fee)
                .WithMany()
                .HasForeignKey(b => b.FeeId);

            modelBuilder.Entity<Fee>()
                .Property(f => f.Fee)
                .HasDefaultValue(0)
                .HasChecckConstraint("CK_Fee_NonNegative", "Fee >= 0")

                 modelBuilder.Entity<billMaster>()
                .Property(b => b.billMaster)
                .HasDefaultValue(0)
                .HasChecckConstraint("CK_billMaster_NonNegative", "billMaster >= 0")

                base.OnModelCreating(modelBuilder);

        }

        




    }
}
