﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BillManagement_DAL.Model
{
    public class Fee
    {
        public int FeeId { get; set; }
        public string CarType { get; set; }
        public string CarName { get; set; }
        public string FuelType { get; set; }
        public int AverageInKm { get; set; }
        public int CostOfFuel { get; set; }
        public int WearTearCost { get; set; }
        public int DriverCharges { get; set; }
        public int CarPoolCommision { get; set; }


    }
}
