﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BillManagement_DAL.Model
{
    public class billMaster
    {
        public int BillId { get; set; }

        public string RideId { get; set; }
        public string NoOfKm { get; set; }
        public int TotalBill { get; set; }
        public int NoOfOccupants { get; set; }
        public int FeeId { get; set; }
        public int CostPerOccupant { get; set; }
        
    }
}
